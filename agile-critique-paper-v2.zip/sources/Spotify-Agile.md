# Spotify & Agile

_Cultural lessons from the Spotify model._