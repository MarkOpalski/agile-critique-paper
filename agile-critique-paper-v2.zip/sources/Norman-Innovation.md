# Norman: Innovation & Design Thinking

_Insights from Norman & Verganti._