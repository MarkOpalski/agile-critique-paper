# IEEE: Why Software Fails

_Annotated summary and excerpts._