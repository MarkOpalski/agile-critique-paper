# Findings

_Present the core findings and supporting points._