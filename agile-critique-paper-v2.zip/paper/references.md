# References

_Formatted citations (manual or Zotero-generated)._