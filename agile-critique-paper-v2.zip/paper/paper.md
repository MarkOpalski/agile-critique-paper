# Full Paper

_This can be assembled from the modular parts above._