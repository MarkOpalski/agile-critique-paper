# Agile Critique Paper

This repository contains a collaboratively written research paper exploring the structural, cultural, and cognitive challenges of Agile practices.