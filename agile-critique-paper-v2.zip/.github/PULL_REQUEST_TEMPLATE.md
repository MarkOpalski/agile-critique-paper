## Pull Request Template

- [ ] This PR includes new or updated content
- [ ] All Markdown files are properly formatted
- [ ] Citations are included if relevant